document.write('<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="120" height="220">');
document.write('<param name="movie" value="http://www.cocolog-nifty.com/cocolo/clock/CharacterClock.swf" />');
document.write('<param name="quality" value="high" />');
document.write('<param name="wmode" value="transparent" />');
document.write('<param name="allowScriptAccess" value="always" />');
document.write('<embed src="http://www.cocolog-nifty.com/cocolo/clock/CharacterClock.swf" type="application/x-shockwave-flash" width="120" height="220" quality="high" wmode="transparent" allowScriptAccess="always" />');
document.write('</object>');
