(function () {
    var isSmartphone = function () {
        if (navigator.userAgent.match(/\((?:(?:iPhone|iPod); U; CPU iPhone OS|Linux; U; Android) /)) {
            return true;
        }
        return false;
    };
    var getSmartphoneUrl = function () {
        var current_url = location.href.replace(/[^\:\/\.\-\_a-z0-9].*$/i, '');
        var base_url = '^' + ld_blog_vars.url;
        var smartphone_base_url = ld_blog_vars.url + 'lite/';
        var smartphone_url = current_url.replace(RegExp(base_url), smartphone_base_url);
        return smartphone_url;
    };
    if (!isSmartphone()) return false;
    var smartphoneUrl = getSmartphoneUrl();
    if (!smartphoneUrl.length) return false;
    var sphd = document.createElement('div');
    sphd.id = 'smartphone';
    var src = '';
    src += '<style type="text/css">\n';
    src += '#smartphone {\n';
    src += '  background-color: #515151;\n';
    src += '  padding: 30px 0px;\n';
    src += '  text-align: center;\n';
    src += '}\n';
    src += '.smartphonelink {\n';
    src += '  padding: 20px;\n';
    src += '  font-size: 60px;\n';
    src += '  color: #333;\n';
    src += '  font-weight: bold;\n';
    src += '  text-decoration: none;\n';
    src += '  text-align: center;\n';
    src += '  background: -webkit-gradient(linear,left top,left bottom,color-stop(0, #ffffff),color-stop(0.50, #d6d6d6),color-stop(0.50, #bebebe),color-stop(1, #ffffff));\n';
    src += '  -webkit-box-shadow: 0px 1px 2px #989898;\n';
    src += '  -webkit-border-radius: 20px;\n';
    src += '  text-shadow: 0px 1px 1px #fff;\n';
    src += '  margin: 0 auto;\n';
    src += '}\n';
    src += '</style>\n';
    src += '<a' + ' href="' + smartphoneUrl + '" class="smartphonelink">';
    src += unescape('%u30B9%u30DE%u30FC%u30C8%u30D5%u30A9%u30F3%u7248%u3078');
    src += '</a>'
    sphd.innerHTML = src;
    document.body.appendChild(sphd);
})();
